DeepSeek-R1-AWQ EP64 traffic matrices

870 CSV matrices: 3 batch sizes x 58 MoE layers x 5 sampled iterations.
Batches: 1024, 2048, 4096.
Layer IDs: 3 through 60.
Iterations (zero-based): 100, 175, 250, 325, 399.

One file per (layer, iteration), grouped by batch:
  batch_4096/layer_047_iteration_0399.csv

Each file is a plain 64 x 64 integer array, with no header or index column:
  Row i = source rank i (0-63).
  Column j = destination rank j (0-63).
  Cell (i,j) = number of token/expert assignments dispatched at that step.
Diagonal cells represent local work; they are included, but are not network traffic.
Each selected expert contributes one assignment, including multiple experts on the
same destination rank. These are the expert-route counts used in the figures,
not the alternative destination-deduplicated convention.

All files are actual single-iteration matrices, with no averaging.
Only the five retained iterations are exported, not all 400 replay iterations.
Source ownership is modeled: balanced persistent request slots on each rank.
Expert placement is learned per layer from the first 100 steps, then frozen.
-1 route padding is excluded, so totals can be slightly less than batch x 8.

manifest.csv lists batch, layer, iteration, filename, SHA-256 and total assignments.
All exported matrices were checked against the original traffic_snapshots.npz.
